package com.mycompany.javafxapplication1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;


public class CreatefileController {
  private String fileName = "jdbc:sqlite:comp20081.db";
    private int timeout = 30;
    private String dataBaseName = "COMP20081";
    private String dataBaseTableName = "FilesUser";
    Connection connection = null;
    private Random random = new SecureRandom();
    private String characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private int iterations = 10000;
    private int keylength = 256;
     private String saltValue;
     
     
    @FXML
    private Button HomeBtn;
     @FXML
     private Button shareFilesBtn;
     
    @FXML
     private Button goToShowBtn;
     
   @FXML
    private Button encryptFileBtn;
     @FXML
    private Button splitFileBtn;
     @FXML
    private TextField splitTextField;
     @FXML
    private TextField encryptTextField;
  @FXML
    private Button containerBtn;

    @FXML
    private Button createNewFilebtn;

    @FXML
    private Button deleteFIlebtn;

    @FXML
    private Button updateFIleBtn;
    
    @FXML
    private Button goToProcessBtn;
    
    @FXML
    private TextField createFileTextField;
    
    @FXML
    private TextField updateFileTextField;

    @FXML
    private TextField deleteFileTextField;
    @FXML
    private TextField recoverTextField;
    
    @FXML
    private TextArea resultTextArea;
     @FXML
    private TextArea filesTextArea;
     
     @FXML
    private Button showFilesBtn;

@FXML
private void createFileHndler(ActionEvent event) throws IOException, ClassNotFoundException, InvalidKeySpecException, SQLException {
    LocalDateTime myDateObj = LocalDateTime.now();
    try {
        String currentUserName = userSession.getInstance().getCurrentUsername();
        String fileName = createFileTextField.getText();
        File myObj = new File(fileName);
        if (myObj.createNewFile()) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDateTime = myDateObj.format(formatter);
            long fileSize = myObj.length();

            // Add the file data to the database
            addDataToDB(myObj.getName(), (int) fileSize, formattedDateTime, currentUserName); // assuming userId is accessible

            // Grant write permission to the user for the newly created file
            grantWritePermission(currentUserName, fileName);

            resultTextArea.appendText("File created: " + myObj.getName() + " at " + formattedDateTime + "\n");

            // Log the file creation event
            String logMessage = "User '" + currentUserName + "' created file: '" + fileName + "' at " + formattedDateTime;
            AuditTrailLogger.log( logMessage);
        } else {
            resultTextArea.appendText("File already exists.");
        }
    } catch (IOException e) {
        resultTextArea.appendText("An error occurred.");
        e.printStackTrace();
    }
}
private void grantWritePermission(String userName, String fileName) {
    try (Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
        String query = "INSERT INTO FilePermissions (FileName, userName, Permission) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, fileName);
            statement.setString(2, userName);
            statement.setString(3, "WRITE");
            statement.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@FXML
private void deleteFileHndler(ActionEvent event) {
    LocalDateTime myDateObj = LocalDateTime.now();
    String fileName = deleteFileTextField.getText();
    File myObj = new File(fileName);

    try {
        // Verify if the file exists
        if (!myObj.exists()) {
            resultTextArea.appendText("File not found: " + fileName);
            System.out.println("File not found: " + fileName);
            return;
        }

        // Print information before deletion
        System.out.println("Deleting file: " + myObj.getAbsolutePath());

        // Backup the file before deletion
        File backupDirectory = new File("/home/ntu-user/NetBeansProjects/Systems-CourseWork-/JavaFXApplication1/backup/");
        functions.deleteFileWithBackup(myObj, backupDirectory);

        LocalDateTime deletionTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = deletionTime.format(formatter);
        
        // Remove the file from the database
        removeFileFromDB(fileName);

        resultTextArea.appendText("Deleted the file: " + myObj.getName() + " at " + formattedDateTime + "\n");

        // Log the file deletion event
        AuditTrailLogger.log("Deleted the file: " + myObj.getName());
    } catch (IOException e) {
        resultTextArea.appendText("An error occurred: " + e.getMessage());
        e.printStackTrace();
    }
}

@FXML
private void updateFileHndler(ActionEvent event) {
    DB db = new DB();
    try {
        String filePath = updateFileTextField.getText();
        String currentUser = userSession.getInstance().getCurrentUsername(); // Get the current username

        // Check if current user has permission to update the file
        if (!db.hasPermission(currentUser, filePath, "WRITE")) {
            resultTextArea.appendText("You don't have permission to update this file.");
            return;
        }

        // Read content of the file
        String existingContent = new String(Files.readAllBytes(Paths.get(filePath)));

        // Show a TextInputDialog with the existing content
        TextInputDialog dialog = new TextInputDialog(existingContent);
        dialog.setTitle("Edit File Content");
        dialog.setHeaderText("Edit the content of the file:");
        dialog.setContentText("Content:");

        // Get  new content from the user
        Optional<String> result = dialog.showAndWait();

        result.ifPresent(newContent -> {
            try {
                // Write the new content back to the file
                FileWriter myWriter = new FileWriter(filePath);
                myWriter.write(newContent);
                myWriter.close();

                // Get  file size
                long fileSize = new File(filePath).length();

                // Get  mod date
                String modificationDate = LocalDateTime.now().toString();

                // Update  FilesUser table
                db.updateFileDetails(filePath, fileSize, modificationDate);

                resultTextArea.appendText("Successfully wrote to the file.");

                // Log the file update event
                AuditTrailLogger.log("Updated the file: " + filePath);
            } catch (IOException e) {
                resultTextArea.appendText("An error occurred.");
                e.printStackTrace();
            }
        });
    } catch (IOException e) {
        resultTextArea.appendText("An error occurred.");
        e.printStackTrace();
    }
}

@FXML
private void RecoverHandler(ActionEvent event) {
    try {
        // Get  filename to recover from the user
        String fileName = recoverTextField.getText();
        
        // Specify the backup directory
        File backupDirectory = new File("/home/ntu-user/NetBeansProjects/Systems-CourseWork-/JavaFXApplication1/backup/");
        
        // Check if file exists in the backup directory
        File backupFile = new File(backupDirectory, fileName);
        if (!backupFile.exists()) {
            resultTextArea.appendText("File '" + fileName + "' not found in the backup directory.");
            return;
        }
        
        // Specify the destination directory to recover the file
        File destinationDirectory = new File("/home/ntu-user/NetBeansProjects/Systems-CourseWork-/JavaFXApplication1/");
        if (!destinationDirectory.exists()) {
            destinationDirectory.mkdirs();
        }
        
        // Specify the destination file path
        File destinationFile = new File(destinationDirectory, fileName);
        
        // Copy  file from backup directory to the destination directory
        Files.copy(backupFile.toPath(), destinationFile.toPath());
        
        resultTextArea.appendText("File '" + fileName + "' successfully recovered.");
    } catch (IOException e) {
        resultTextArea.appendText("An error occurred while recovering the file: " + e.getMessage());
        e.printStackTrace();
    }
}



      @FXML
    private void goToProcessHandler(ActionEvent event) {
            Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goToProcessBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("runProcess.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
              secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
public void addDataToDB(String fileName, int size, String creationDate,String User) throws InvalidKeySpecException, ClassNotFoundException, SQLException {
    try {
        
        Class.forName("org.sqlite.JDBC");
        Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db"); // Use the correct database URL
        connection.setAutoCommit(false); // Start a transaction

      
        PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO " + dataBaseTableName + " (FileName, size, creationDate,userId) VALUES (?, ?, ?,?)"
        );

        
        preparedStatement.setString(1, fileName);
        preparedStatement.setInt(2, size);
        preparedStatement.setString(3, creationDate);
        preparedStatement.setString(4,User);

        
        preparedStatement.executeUpdate();

       
        connection.commit();
    } catch (SQLException ex) {
        ex.printStackTrace();
        
        connection.rollback();
    }
}
public void removeFileFromDB(String fileNameToDelete) {
    try {
        
        Class.forName("org.sqlite.JDBC");
        Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db"); // Use the correct database URL
        connection.setAutoCommit(false); 

        
        PreparedStatement preparedStatement = connection.prepareStatement(
                "DELETE FROM " + dataBaseTableName + " WHERE FileName = ?"
        );

        
        preparedStatement.setString(1, fileNameToDelete);

       
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            
            connection.commit(); 
            System.out.println("Deleted the file '" + fileNameToDelete + "' from the database.");
        } else {
            
            System.out.println("File '" + fileNameToDelete + "' not found in the database.");
        }

       
        connection.close();
    } catch (SQLException | ClassNotFoundException ex) {
        ex.printStackTrace();
        System.out.println("An error occurred while deleting the file from the database.");
    }
}

    @FXML
   private void shareFilesHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  shareFilesBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ShareFiles.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
              secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
   private void goToShowHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goToShowBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ShowFiles.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
              secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
@FXML

private void goToContainers(ActionEvent event) {
Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  containerBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("FileToContainers.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   @FXML
    private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
   
}



