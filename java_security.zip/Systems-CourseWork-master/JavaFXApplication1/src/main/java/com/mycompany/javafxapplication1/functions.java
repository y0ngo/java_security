package com.mycompany.javafxapplication1;
import com.jcraft.jsch.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import javax.crypto.BadPaddingException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;



public class functions {
     private String fileName = "jdbc:sqlite:comp20081.db";
    private int timeout = 30;
    private String dataBaseName = "COMP20081";
    private String dataBaseTableName = "FilesUser";
    Connection connection = null;
    private java.util.Random random = new SecureRandom();
    private String characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private int iterations = 10000;
    private int keylength = 256;
    
 private static final String USERNAME = "root";
    private static final String PASSWORD = "ntu-user";
    private static final int REMOTE_PORT = 22;
     private static final String REMOTE_HOST = "172.18.0.3";
    private static final int SESSION_TIMEOUT = 10000;
    private static final int CHANNEL_TIMEOUT = 5000;
    private static final Map<String, String> CONTAINER_IP_MAP = new HashMap<>();

  

   private static SecretKey generateValidAESKey(String secretKeyString) throws NoSuchAlgorithmException {
      
        byte[] keyBytes = secretKeyString.getBytes(StandardCharsets.UTF_8);

      
        byte[] validKeyBytes = Arrays.copyOf(keyBytes, 16); // Assuming 128-bit key length

      
        return new SecretKeySpec(validKeyBytes, "AES");
    }


public static void sendEncryptedFiles(String localFile, String remoteDirectory, int numContainers) throws NoSuchAlgorithmException, IOException {
    Session jschSession = null;

    try {
        for (int i = 1; i <= numContainers; i++) {
            String containerName = "comp20081-files-container" + i;

            JSch jsch = new JSch();
            jsch.setKnownHosts("/home/mkyong/.ssh/known_hosts");

            // Set the StrictHostKeyChecking option to "no" to automatically answer "yes" to the prompt
            jschSession = jsch.getSession(USERNAME, containerName, REMOTE_PORT);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            jschSession.setConfig(config);

            // authenticate using password
            jschSession.setPassword(PASSWORD);

            // 10 seconds session timeout
            jschSession.connect(SESSION_TIMEOUT);

            Channel sftp = jschSession.openChannel("sftp");

            // 5 seconds timeout
            sftp.connect(CHANNEL_TIMEOUT);

            ChannelSftp channelSftp = (ChannelSftp) sftp;

            // Define the local file name for the encrypted chunk
            String localFileName = localFile + "_part" + i + "_encrypted";

            // Define the remote file name for the encrypted chunk
            String remoteFileName = new File(localFileName).getName();

            // Transfer encrypted chunk from local to remote server
            channelSftp.put(localFileName, remoteDirectory + remoteFileName);

            channelSftp.exit();

            System.out.println("Done transferring encrypted chunk to container: " + containerName);
        }
    } catch (JSchException | SftpException e) {
        e.printStackTrace();
    } finally {
        if (jschSession != null) {
            jschSession.disconnect();
        }
    }
}

public static void downloadEncryptedFiles(String localDirectory, String remoteDirectory, int numContainers, String originalFileName) throws NoSuchAlgorithmException, IOException {
    Session jschSession = null;

    try {
        for (int i = 1; i <= numContainers; i++) {
            String containerName = "comp20081-files-container" + i;

            JSch jsch = new JSch();
            jsch.setKnownHosts("/home/mkyong/.ssh/known_hosts");

            // Set the StrictHostKeyChecking option to "no" to automatically answer "yes" to the prompt
            jschSession = jsch.getSession(USERNAME, containerName, REMOTE_PORT);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            jschSession.setConfig(config);

            // authenticate using password
            jschSession.setPassword(PASSWORD);

            // 10 seconds session timeout
            jschSession.connect(SESSION_TIMEOUT);

            Channel sftp = jschSession.openChannel("sftp");

            // 5 seconds timeout
            sftp.connect(CHANNEL_TIMEOUT);

            ChannelSftp channelSftp = (ChannelSftp) sftp;

            // Define the remote file name for the encrypted chunk
            String remoteFileName = originalFileName + "_part" + i + "_encrypted";

            // Define the local file name for the downloaded chunk
            String localFileName = localDirectory + originalFileName + "_part" + i + "_encrypted";

            // Download encrypted chunk from remote server to local machine
            channelSftp.get(remoteDirectory + remoteFileName, localFileName);

            channelSftp.exit();

            System.out.println("Done downloading encrypted chunk from container: " + containerName);
        }
    } catch (JSchException | SftpException e) {
        e.printStackTrace();
    } finally {
        if (jschSession != null) {
            jschSession.disconnect();
        }
    }
}




    public static SecretKey generateRandomAESKey() throws NoSuchAlgorithmException {
    KeyGenerator keyGen = KeyGenerator.getInstance("AES");
    keyGen.init(256);
    return keyGen.generateKey();
}

    public static void req7(String host,String command1) {
	  
	    String user="root";
	    String password="ntu-user";
	   
	    try{
	    	
	    	java.util.Properties config = new java.util.Properties(); 
	    	config.put("StrictHostKeyChecking", "no");
	    	JSch jsch = new JSch();
	    	Session session=jsch.getSession(user, host, 22);
	    	session.setPassword(password);
	    	session.setConfig(config);
	    	session.connect();
	    	System.out.println("Connected");
	    	
	    	Channel channel=session.openChannel("exec");
	        ((ChannelExec)channel).setCommand(command1);
	        channel.setInputStream(null);
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        InputStream in=channel.getInputStream();
	        channel.connect();
	        byte[] tmp=new byte[1024];
	        while(true){
	          while(in.available()>0){
	            int i=in.read(tmp, 0, 1024);
	            if(i<0)break;
	            System.out.print(new String(tmp, 0, i));
	          }
	          if(channel.isClosed()){
	            System.out.println("exit-status: "+channel.getExitStatus());
	            break;
	          }
	          try{Thread.sleep(1000);}catch(Exception ee){}
	        }
	        channel.disconnect();
	        session.disconnect();
	        System.out.println("DONE");
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
    }
 

 

public static void chunksAndEncrypt(String inputFile, SecretKey secretKey, int numContainers, String userName) throws IOException {
    File file = new File(inputFile);
     String username = userSession.getInstance().getCurrentUsername();
    try (FileInputStream fis = new FileInputStream(file)) {
        long fileSize = file.length(); // Get file size in bytes
        int chunkCount = numContainers; // Number of chunks

        long chunkSize = fileSize / chunkCount; // Size of each chunk
        byte[] buffer = new byte[(int) chunkSize]; // Buffer size for each chunk
        int bytesRead;
        int partNumber = 1;

        
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
            conn.setAutoCommit(false); // Begin transaction

            while ((bytesRead = fis.read(buffer)) > 0 && partNumber <= chunkCount) {
                String outputFileName = inputFile + "_part" + partNumber + "_encrypted";
                File outputFile = new File(outputFileName);
                try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                    // Encrypt  chunk before writing it to the file
                    encryptChunk(buffer, bytesRead, fos, secretKey);
                }

                // Store encryption key in the database
                storeEncryptionKey(conn, userName, secretKey,file);

                partNumber++;
                System.out.println("Created and encrypted chunk: " + outputFileName);
            }

            conn.commit(); // Commit transaction
        } catch (SQLException e) {
            // Handle database errors
            e.printStackTrace();
        }
    }
}

public static void decryptAndJoinChunks(String originalFileName, int numContainers, String encryptionKeyBase64, String decryptedFilePath) throws IOException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeyException {
    byte[] buffer = new byte[1024]; 
    int bytesRead;
    File outputFile = new File(decryptedFilePath);

    // Decode the Base64-encoded encryption key
    byte[] decodedKey = Base64.getDecoder().decode(encryptionKeyBase64);
    SecretKey secretKey = new SecretKeySpec(decodedKey, "AES");

    try (FileOutputStream fos = new FileOutputStream(outputFile)) {
        for (int i = 1; i <= numContainers; i++) {
            // Define the local file name for the downloaded chunk
            String localFileName = originalFileName + "_part" + i + "_encrypted";

            try (FileInputStream fis = new FileInputStream(localFileName)) {
                // Initialize the cipher for decryption
                Cipher cipher = Cipher.getInstance("AES");
                cipher.init(Cipher.DECRYPT_MODE, secretKey);

                while ((bytesRead = fis.read(buffer)) != -1) {
                    // Decrypt the chunk and write it to the output file
                    byte[] decryptedBytes = cipher.update(buffer, 0, bytesRead);
                    if (decryptedBytes != null) {
                        fos.write(decryptedBytes);
                    }
                }

                
                byte[] decryptedBytes = cipher.doFinal();
                if (decryptedBytes != null) {
                    fos.write(decryptedBytes);
                }
            }
        }
    }
}
public static void decryptChunk(byte[] buffer, int bytesRead, OutputStream outputStream, SecretKey secretKey) throws IllegalBlockSizeException, BadPaddingException {
    try {
        // Initialize the cipher for decryption
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[16]);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);

        // Decrypt the chunk and write it to the output stream
        byte[] decryptedBytes = cipher.doFinal(buffer, 0, bytesRead);
        outputStream.write(decryptedBytes);
    } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidAlgorithmParameterException
            | InvalidKeyException | IllegalBlockSizeException | BadPaddingException | IOException e) {
        // Handle decryption errors
        e.printStackTrace();
    }
}

private static void storeEncryptionKey(Connection conn, String userName, SecretKey secretKey, File inputFile) throws SQLException {
    // Insert the encryption key into the database
     
    String fileName = inputFile.getName();
    
    String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
    
    String insertQuery = "INSERT INTO EncryptionKeys (userName, key,fileName) VALUES (?, ?,?)";
    try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
        stmt.setString(1, userName);
        stmt.setString(2,encodedKey);
        stmt.setString(3,fileName);
        
        stmt.executeUpdate();
    }
}

  
  



private static void encryptChunk(byte[] buffer, int bytesRead, OutputStream outputStream, SecretKey secretKey) throws IOException {
    try {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        try (CipherOutputStream cipherOutputStream = new CipherOutputStream(outputStream, cipher)) {
            // Write the encrypted chunk data to the output stream
            cipherOutputStream.write(buffer, 0, bytesRead);
        }
    } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
        e.printStackTrace();
    }
}
 public static void moveFileToDirectory(File file, File directory) throws IOException {
        if (!directory.exists()) {
            directory.mkdirs();
        }
        Files.move(file.toPath(), directory.toPath().resolve(file.getName()), StandardCopyOption.REPLACE_EXISTING);
    }
    public static void deleteFileWithBackup(File file, File backupDirectory) throws IOException {
        if (file.exists()) {
            moveFileToDirectory(file, backupDirectory);
            file.delete();
        } else {
            System.out.println("File does not exist.");
        }
    }





     
        

   public void createTable(String tableName) throws ClassNotFoundException {
        try {
            // create a database connection
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("create table if not exists " + tableName + "(FileName string, size integer, creationDate string,modificationDate string,userId integer,FOREIGN KEY (userId)REFERENCES Users(id)");
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e.getMessage());
            }
        }
    }
      public void delTable(String tableName) throws ClassNotFoundException {
        try {
            // create a database connection
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(fileName);
            var statement = connection.createStatement();
            statement.setQueryTimeout(timeout);
            statement.executeUpdate("drop table if exists " + tableName);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e.getMessage());
            }
        }
    }
public static void showFilesForUser(String username) {
        
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
            // Prepare the SQL query
            String query = "SELECT FileName, Permission FROM FilePermissions WHERE name= (SELECT name FROM Users WHERE Name = ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                // Set the username parameter
                statement.setString(1, username);
                // Execute the query
                try (ResultSet resultSet = statement.executeQuery()) {
                    // Process the results and display files based on permissions
                    System.out.println("Files accessible to user " + username + ":");
                    while (resultSet.next()) {
                        String fileName = resultSet.getString("FileName");
                        String permission = resultSet.getString("Permission");
                        if (permission.equals("READ") || permission.equals("WRITE")) {
                            System.out.println(fileName);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions
            e.printStackTrace();
        }
    }
}
    
       
  



    
	