package com.mycompany.javafxapplication1;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.security.spec.InvalidKeySpecException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;


    


public class UserManagementController {


 

    @FXML
    private Button backLoginBtn;

    @FXML
    private Button confirmBtn;

    @FXML
    private PasswordField newPasswordTextField;

    @FXML
    private TextField newUserTextField;

    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;

   @FXML
private void confirmHandler(ActionEvent event) throws IOException {
    DB db = new DB();
    String oldUsername = userTextField.getText();
    String oldPassword = passwordTextField.getText();
    String newUsername = newUserTextField.getText();
    String newPassword = newPasswordTextField.getText();
    String currentUser = userSession.getInstance().getCurrentUsername(); // Get the current username

    
    if (oldUsername.isEmpty() || oldPassword.isEmpty() || newUsername.isEmpty() || newPassword.isEmpty()) {
        showDialog("Validation Error", "Please fill in all fields.");
        return; 
    }

    try {
        // Check if the current username and password are correct
        if (!db.validateUser(oldUsername, oldPassword)) {
            showDialog("Validation Error", "Incorrect current username or password.");
            return; // Exit the method if credentials are incorrect
        }

        // Call the updateUserData method from the DB instance
        db.updateUserData(oldUsername, newUsername, newPassword);

        // Log the user update event
        String eventMessage = "User data updated: Changed username from " + oldUsername + " to " + newUsername + " by: " + currentUser;
        AuditTrailLogger.log( eventMessage);
        System.out.println("Audit log: " + eventMessage);

        showDialog("Updating information", "Successful!");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("secondary.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

    } catch (InvalidKeySpecException | ClassNotFoundException ex) {
        showDialog("Updating information", "Failed!");
        ex.printStackTrace();
    }
}
    @FXML
    private void backLoginHandler(ActionEvent event) {
         Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  backLoginBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("primary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
        private void showDialog(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

