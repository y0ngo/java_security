/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.javafxapplication1;

import static com.mycompany.javafxapplication1.functions.downloadEncryptedFiles;
import static com.mycompany.javafxapplication1.functions.generateRandomAESKey;
import static com.mycompany.javafxapplication1.functions.sendEncryptedFiles;
import java.io.File;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * FXML Controller class
 *
 * @author ntu-user
 */

public class FileToContainersController{
    private static final String REMOTE_HOST = "172.18.0.2";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "soft40051_pass";
    private static final int REMOTE_PORT = 22;
    private static final int SESSION_TIMEOUT = 10000;
    private static final int CHANNEL_TIMEOUT = 5000;
    private Map<String, String> CONTAINER_IP_MAP = new HashMap<>();
    @FXML
    private Button containerBtn;
    @FXML
    private Button retrieveBtn;
     @FXML
    private Button FilesBtn;
         @FXML
    private Button HomeBtn;
             @FXML
    private Button encryptionBtn;

@FXML
    private Button commandBtn;
 @FXML
    private TextField encryptionTextField;
    
    
    @FXML
    private TextField fileTextField;
@FXML
    private void containerHandler(ActionEvent event) {
        String fileName = fileTextField.getText();
        File file = new File(fileName);
        String username = userSession.getInstance().getCurrentUsername();

        if (!file.exists()) {
            showDialog("Error", "This file does not exist ");
            return;
        }

        try {
            // Encrypt the file into chunks for each container
            showDialog("Encrypting File", "Encrypting file into chunks...");
            functions.chunksAndEncrypt(fileName, generateRandomAESKey(), 4, username); // Adjust number of containers accordingly
            showDialog("Success", "File encrypted into chunks successfully.");

            // Send  encrypted chunks to containers
            showDialog("Sending Chunks", "Sending encrypted chunks to containers...");
            sendEncryptedFiles(fileName, "/root/", 4); // Adjust the remote directory and number of containers accordingly
            showDialog("Success", "Encrypted chunks sent to containers successfully.");

           
            String eventMessage = "Handled containers for file: " + fileName;
            AuditTrailLogger.log( eventMessage);
            System.out.println("Audit log: " + eventMessage);
        } catch (IOException | NoSuchAlgorithmException e) {
            showDialog("Error", "Error processing file: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for debugging
        }
    }

@FXML
private void retrieveHandler(ActionEvent event) {
    String fileName = fileTextField.getText();
    String encryptionKeyBase64 = encryptionTextField.getText(); 

    String localDirectory = "/home/ntu-user/NetBeansProjects/Systems-CourseWork-/JavaFXApplication1/";
    int numContainers = 4; // Specify the number of containers
    String decryptedFileName = "decrypted_" + fileName; // Specify the name for the decrypted file

    try {
        // Decrypt and join chunks
        functions.decryptAndJoinChunks(localDirectory + fileName, numContainers, encryptionKeyBase64, localDirectory + decryptedFileName);

      

        // Log the retrieval event
        String eventMessage = "Retrieved and decrypted file: " + fileName;
        AuditTrailLogger.log(eventMessage);
        System.out.println("Audit log: " + eventMessage);
    } catch (NoSuchAlgorithmException | IOException | IllegalBlockSizeException | BadPaddingException | NoSuchPaddingException | InvalidKeyException e) {
        e.printStackTrace();
        // Handle any exceptions or errors that occur during the retrieval and decryption process.
    }
}


  @FXML
    private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
      @FXML
    private void FilesHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  FilesBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("createfile.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
      @FXML
    private void commandHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  commandBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("req7.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @FXML
    private void encryptionHandler(ActionEvent event) {
Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  encryptionBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ShowKeys.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

private void showDialog(String title, String content) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(content);
    alert.showAndWait();
}
}


