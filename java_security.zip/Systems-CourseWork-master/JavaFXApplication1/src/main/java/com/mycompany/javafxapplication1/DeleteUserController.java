/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.IOException;
import java.security.spec.InvalidKeySpecException;
import java.time.LocalDateTime;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DeleteUserController {

    @FXML
    private Button cancelBtn;

    @FXML
    private Button deleteBtn;

    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;

    @FXML
    private void CancelHandler(ActionEvent event) {
               Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  cancelBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("primary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

 @FXML
    private void deleteHandler(ActionEvent event) throws IOException {
        DB db=new DB();
        String username = userTextField.getText();
        String password = passwordTextField.getText();
        LocalDateTime myDateObj = LocalDateTime.now();
        try {
            // Check current username and password are correct
            if (!db.validateUser(username, password)) {
                showDialog("Validation Error", "Incorrect current username or password.");
                return; // Exit the method if credentials are incorrect
            }

            // Call updateUser method from the DB 
            db.deleteUser(username, password);
            showDialog("Deleting", "Successful!");

            // Log the deletion event
            String eventMessage = "Deleted user: " + username;
            AuditTrailLogger.log(eventMessage);
            System.out.println("Audit log: " + eventMessage);

          
            FXMLLoader loader = new FXMLLoader(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (InvalidKeySpecException | ClassNotFoundException ex) {
            showDialog("Updating information", "Failed!");
            ex.printStackTrace();
        }
    }
   private void showDialog(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

