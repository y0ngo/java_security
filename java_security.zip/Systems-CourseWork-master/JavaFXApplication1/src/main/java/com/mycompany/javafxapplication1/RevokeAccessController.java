/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ntu-user
 */
public class RevokeAccessController {
    @FXML
    private Button goBackToShareBtn;
    
    @FXML
    private TextField fileTextField;
    
    
   
    @FXML
    private TextField userTextField;
    
    @FXML
   private void Revoke(ActionEvent Event ){ 
     DB db = new DB();
    String fileName = fileTextField.getText();
    String user = userTextField.getText();
    String currentUser = userSession.getInstance().getCurrentUsername(); // Get the current username

    File file = new File(fileName);
    if (!file.exists()) {
       showDialog("Error", "This file does not exist ");
        return;
    }

    if (!db.isValidUserName(user)) {
        showDialog("Error", "This user does not exist ");
        return;
    }   try {
        revokeFileAccess(fileName,  user);

        // Log the file sharing event
        String eventMessage = "Revoked File: " + fileName + " from :  " + user + " by: " + currentUser;
        AuditTrailLogger.log( eventMessage);
        System.out.println("Audit log: " + eventMessage);

        showDialog("Successful", "Revoked File : " + user);
    } catch (Exception e) {
        showDialog("Failed", "Error revoking the file");
    }
    
    
}
      @FXML
    private void goBackToShareHandler(ActionEvent event) {
              Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goBackToShareBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ShareFiles.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
   public void revokeFileAccess(String fileName, String UserName) throws SQLException {
    try (Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
        String query = "DELETE FROM FilePermissions WHERE FileName = ? AND userName = (SELECT name FROM Users WHERE Name = ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, fileName);
            statement.setString(2, UserName);
            statement.executeUpdate();
        }
    }
   }
       private void showDialog(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
     
}
