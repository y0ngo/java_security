package com.mycompany.javafxapplication1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class RunProcessController {

    @FXML
    private Button processBtn;
       @FXML
    private Button HomeBtn;


    @FXML
    private TextField processTextField;

    @FXML
    private TextArea resultTextArea;
    
    @FXML
    private Button goToContainersBtn;

 @FXML
private void processHandler(ActionEvent event) throws IOException {
    resultTextArea.clear();
    
    String command = processTextField.getText();
    String[] commandArray = command.split("\\s+");

    String[] validCommands = {"ls", "mkdir", "cp", "mv", "ps", "whoami", "tree", "nano"};
    boolean valid = false;
    boolean isNano = false;

    // Check if the entered command is valid
    for (String validCommand : validCommands) {
        if (validCommand.equals(commandArray[0])) {
            valid = true;
            break;
        }
    }

    if ("nano".equals(commandArray[0])) {
        isNano = true;
    }

    if (isNano) {
        
        String nanoResult = nano(command);
        
        
        resultTextArea.appendText(nanoResult);

        
        String currentUser = userSession.getInstance().getCurrentUsername();
        AuditTrailLogger.log( "Executed nano command: " + command);
    } else if (valid && !"nano".equals(commandArray[0])) {
        
        String commandResult = command(command);
        
        
        resultTextArea.appendText(commandResult);

        
        String currentUser = userSession.getInstance().getCurrentUsername();
        AuditTrailLogger.log( "Executed command: " + command);
    }
}
   @FXML
        private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private String nano(String command) throws IOException {
       
        ProcessBuilder processBuilder = new ProcessBuilder("terminator","-e","nano");
        Process process = processBuilder.start();

        
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }

       
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return output.toString();
    }

    private String command(String command) throws IOException {
      
        ProcessBuilder processBuilder = new ProcessBuilder(command);
        Process process = processBuilder.start();

       
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }

      
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return output.toString();
    }
       @FXML     
    private void goToContainersHandler(){
           Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goToContainersBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("req7.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
              secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        

    }
    
      }

