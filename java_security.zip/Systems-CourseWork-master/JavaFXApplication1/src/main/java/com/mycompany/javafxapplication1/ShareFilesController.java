package com.mycompany.javafxapplication1;

import java.io.File;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ShareFilesController {
    @FXML
    private Button HomeBtn;
    @FXML
    private Button goToFilesBtn;
    
    @FXML
    private Button goToRevokeBtn;

    @FXML
    private Button cancelBtn;

    @FXML
    private Button confirmBtn;

    @FXML
    private TextField fileTextField;

    @FXML
    private ComboBox<String> permissionBox;

    @FXML
    private TextField userTextField;

    @FXML
    private void initialize() {
        permissionBox.getItems().addAll(
                "READ",
                "WRITE"
        );
    }

   @FXML
private void confirmHandler(ActionEvent event) {
    DB db = new DB();
    String fileName = fileTextField.getText();
    String permission = permissionBox.getValue();
    String user = userTextField.getText();
    String currentUser = userSession.getInstance().getCurrentUsername(); // Get the current username

    File file = new File(fileName);
    if (!file.exists()) {
       showDialog("Error", "This file does not exist ");
        return;
    }

    if (!db.isValidUserName(user)) {
        showDialog("Error", "This user does not exist ");
        return;
    }

   
    try {
        db.shareFile(fileName, permission, user);

        // Log the file sharing event
        String eventMessage = "File shared: " + fileName + " with permission: " + permission + " with user: " + user + " by: " + currentUser;
        AuditTrailLogger.log( eventMessage);
        System.out.println("Audit log: " + eventMessage);

        showDialog("Successful", "File shared successfully with user: " + user);
    } catch (Exception e) {
        showDialog("Failed", "Error sharing the file");
    }
}
 @FXML
    private void RevokeHandler(ActionEvent event) {
             Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goToRevokeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("RevokeAccess.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

  @FXML
    private void goToFileHandler(ActionEvent event) {
             Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  goToFilesBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("createfile.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @FXML
        private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
     private void showDialog(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
     
     
}
