/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class AuditTrailLogger {
    private static final Logger logger = Logger.getLogger(AuditTrailLogger.class.getName());

    static {
        try {
            FileHandler fh = new FileHandler("audit.log");
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
            logger.addHandler(fh);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void log(String event) {
        String currentUserName = userSession.getInstance().getCurrentUsername();
        logger.info("User: " + currentUserName + " - Event: " + event);
    }
}
