package com.mycompany.javafxapplication1;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BackupCleaner {
    private static final String BACKUP_DIRECTORY_PATH = "/home/ntu-user/NetBeansProjects/Systems-CourseWork-/JavaFXApplication1/backup/";
    private static final Duration MAX_FILE_AGE = Duration.ofDays(31);

    public static void main(String[] args) {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

        // Schedule the task to run every day
        executorService.scheduleAtFixedRate(BackupCleaner::cleanBackupDirectory, 0, 1, TimeUnit.DAYS);
    }

   public static void cleanBackupDirectory() {
        File backupDirectory = new File(BACKUP_DIRECTORY_PATH);

        if (!backupDirectory.exists() || !backupDirectory.isDirectory()) {
            System.err.println("Backup directory not found or is not a directory: " + BACKUP_DIRECTORY_PATH);
            return;
        }

        File[] files = backupDirectory.listFiles();
        if (files == null || files.length == 0) {
            System.out.println("No files found in the backup directory.");
            return;
        }

        for (File file : files) {
            try {
                BasicFileAttributes attributes = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
                Instant creationTime = attributes.creationTime().toInstant();
                Instant currentTime = LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant();

                if (Duration.between(creationTime, currentTime).compareTo(MAX_FILE_AGE) > 0) {
                    if (file.delete()) {
                        System.out.println("Deleted file: " + file.getName());
                    } else {
                        System.err.println("Failed to delete file: " + file.getName());
                    }
                }
            } catch (IOException e) {
                System.err.println("Error reading file attributes: " + e.getMessage());
            }
        }
    }
}