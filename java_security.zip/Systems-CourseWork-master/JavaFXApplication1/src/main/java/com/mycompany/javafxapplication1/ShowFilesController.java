/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author ntu-user
 */
public class ShowFilesController  {
     @FXML
    private Button confirmBtn;
         
     @FXML
    private TextArea fileTextArea;

    /**
     * Initializes the controller class.
     */
   @FXML

private void confirmHandler(ActionEvent event) {
    DB db = new DB();
    
    String username = userSession.getInstance().getCurrentUsername();
    System.out.println("Current Username: " + username);

    try (Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
        String query = "SELECT FileName, Permission FROM FilePermissions WHERE userName = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                fileTextArea.appendText("Files accessible to user :\n");
                while (resultSet.next()) {
                    String fileName = resultSet.getString("FileName");
                    String permission = resultSet.getString("Permission");
                    if (permission.equals("READ") || permission.equals("WRITE")) {
                        fileTextArea.appendText(fileName + "\n");
                    }
                }
            }
        }
    } catch (SQLException e) {
        fileTextArea.appendText("Error accessing files: " + e.getMessage());
        e.printStackTrace();
    }
}


   private void showDialog(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
        // TODO
    }    
    

