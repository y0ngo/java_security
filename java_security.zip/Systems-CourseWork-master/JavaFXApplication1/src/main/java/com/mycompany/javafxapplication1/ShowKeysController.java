package com.mycompany.javafxapplication1;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ntu-user
 */
public class ShowKeysController {
      @FXML
    private Button HomeBtn;

   
    @FXML
    private Button ConfirmBtn;
    @FXML
    private TextArea encryptionTextArea;
    @FXML
    private Button containerBtn;


    /**
     * Initializes the controller class.
     */
public void ConfirmHandler(ActionEvent event) {
    String username = userSession.getInstance().getCurrentUsername();
    System.out.println("Current Username: " + username);

    try (Connection connection = DriverManager.getConnection("jdbc:sqlite:comp20081.db")) {
        String query = "SELECT Key, fileName FROM EncryptionKeys WHERE userName = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                encryptionTextArea.appendText("Files accessible to user: \n");
                while (resultSet.next()) {
                    String fileName = resultSet.getString("fileName");
                    String key = resultSet.getString("Key");
                    encryptionTextArea.appendText("File: " + fileName + ", Key: " + key + "\n");
                }
            }
        }
    } catch (SQLException e) {
        encryptionTextArea.appendText("Error accessing files: " + e.getMessage() + "\n");
        e.printStackTrace();
    }
}


    
    
    
    
    
       @FXML
    private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
        @FXML
    private void containerHandler(ActionEvent event) {
         Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  containerBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("FileToContainers.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
}
