package com.mycompany.javafxapplication1;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Req7Controller {
    
    @FXML
    private TextField recoverTextField;
    
    @FXML
    private Button RecoverBtn;

    @FXML
    private Button commandBtn;
    
    @FXML
    private Button containerBtn;
    @FXML
    private Button HomeBtn;

    @FXML
    private TextField commandTextField;
      @FXML
    private TextArea containerTextArea;


    @FXML
    private ComboBox<String> containerComboBox;  // Specify the type inside the ComboBox

    @FXML
    private void initialize() {
        containerComboBox.getItems().addAll(
                "comp20081-files-container1",
                "comp20081-files-container2",
                "comp20081-files-container3",
                "comp20081-files-container4"
        );
    }

    @FXML
    private void commandHandler(ActionEvent event) throws IOException {
        String containerName = containerComboBox.getValue(); // Retrieve the selected item
        containerTextArea.appendText(containerName);
        String commandInput = commandTextField.getText();

        // Assuming req7 is a static method in the functions class
        functions.req7(containerName, commandInput);
    }
     @FXML
    private void HomeHandler(ActionEvent event) {
        Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  HomeBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("secondary.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @FXML

private void goToContainers(ActionEvent event) {
Stage secondaryStage = new Stage();
        Stage primaryStage = (Stage)  containerBtn.getScene().getWindow();
        try {
            
        
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("FileToContainers.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root, 640, 480);
            secondaryStage.setScene(scene);
              
               secondaryStage.show();
           
            primaryStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   @FXML
    private void RecoverHandler(ActionEvent event) {

    }
}